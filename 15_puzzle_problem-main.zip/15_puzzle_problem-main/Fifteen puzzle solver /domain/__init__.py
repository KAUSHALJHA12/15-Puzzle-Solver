from .puzzle import Puzzle
